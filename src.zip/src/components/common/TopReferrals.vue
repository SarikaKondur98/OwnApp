<template>
  <d-card class="card-small">

    <!-- Card Header -->
    <d-card-header class="border-bottom">
      <h6 class="m-0">{{ title }}</h6>
      <div class="block-handle"></div>
    </d-card-header>

    <d-card-body class="p-0">

      <!-- Top Referrals List Group -->
      <d-list-group flush class="list-group-small">
        <d-list-group-item v-for="(item, idx) in referralData" :key="idx" class="d-flex px-3">
          <img class="user-avatar rounded-circle mr-2" width="30" height="30" src="@/assets/images/avatars/0.jpg" alt="User Avatar"> 
          <span class="text-semibold text-fiord-blue font-size: medium"><b>{{ item.title }}</b></span>
          <span class="ml-auto text-right text-semibold text-reagent-gray"><b>{{ item.value }}</b></span>
        </d-list-group-item>
      </d-list-group>

    </d-card-body>

    <d-card-footer class="border-top">
      <d-row>

        <!-- Time Frame -->
        <d-col>
          <d-select size="sm" value="last-week" style="max-width: 130px;">
            <option value="last-week">Last Week</option>
            <option value="today">Today</option>
            <option value="last-month">Last Month</option>
            <option value="last-year">Last Year</option>
          </d-select>
        </d-col>

        <!-- View Full Report -->
        <!-- <d-col class="text-right view-report">
          <a href="#">View full report &rarr;</a>
        </d-col> -->

      </d-row>
    </d-card-footer>

  </d-card>
</template>

<script>
const defaultTopReferrals = [{
  title: 'Ganesh',
  value: 'Music',
}, {
  title: 'Lohith',
  value: 'Dance',
}, {
  title: 'Pradeep',
  value: 'Paint',
}, {
  title: 'Rakesh',
  value: 'comedy',
}, {
  title: 'Alok',
  value: 'Cricket',
}, {
  title: 'Bharat',
  value: 'Tennies',
}, {
  title: 'Kumar',
  value: 'Base ball',
}, {
  title: 'jai',
  value: 'Badminton',
},
];

export default {
  name: 'ao-top-referrals',
  props: {
    /**
       * The component's title.
       */
    title: {
      type: String,
      default: 'Winners',
    },
    /**
       * The referral datasets.
       */
    referralData: {
      type: Array,
      default() {
        return defaultTopReferrals;
      },
    },
  },
};
</script>
