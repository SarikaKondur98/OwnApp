<template>
  <div>
    <d-modal v-if="popUpModal" @close="handleClose">
      <d-modal-body>You are Successfully Registered</d-modal-body>
    </d-modal>
  </div>
</template>

<script>
export default {
  name: 'DialogPopup',
  data() {
    return {
      popUpModal: false,
    };
  },
  methods: {
    handleClose() {
      this.popUpModal = false;
    },
  },
};
</script>
