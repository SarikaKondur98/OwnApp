<template>
    <d-card class="card-small mb-4">
            <d-card-header class="border-bottom">
              <h6 class="m-0">Profile</h6>
            </d-card-header>
            <d-list-group flush>
              <d-list-group-item class="px-3">
                <div class="mb-2">
                  <strong class="text-muted d-block mb-3">Completed %</strong>
                  <d-progress theme="royal-blue" height="5px" class="mb-3" :value="70" :max="100" />
                </div>
              </d-list-group-item>
            </d-list-group>
    </d-card>
</template>
<script>
export default {
  name: 'profile-progress',
  props: {
    /**
       * The component's title.
       */
    title: {
      type: String,
      default: 'profile Progress',
    },
  },
};
</script>
