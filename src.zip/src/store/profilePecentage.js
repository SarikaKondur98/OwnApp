import usersData from '../data/userdetails.json';
export class calpercent{
        data() {
        return {
        users: usersData, };
        }
    // Lab 5 : Write your code here
}