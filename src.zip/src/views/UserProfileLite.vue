<template>
  <d-container fluid class="main-content-container px-4">
    <!-- Page Header -->
    <d-row no-gutters class="page-header py-4">
      <d-col col sm="4" class="text-center text-sm-left mb-4 mb-sm-0">
        <span class="text-uppercase page-subtitle">Overview</span>
        <h3 class="page-title">User Profile</h3>
      </d-col>
    </d-row>

    <!-- Content -->
    <d-row>
      <d-col lg="4">
        <upl-user-details :userDetails="defaultUserDetails" />
      </d-col>
      <d-col lg="8">
        <upl-user-account-details
          ref="userAccountDetails"
          @emitProgressBarValue="calculateProgressBarValue"
          @emitProgressBarValue1="calculateProgressBarValue1"
          @emitProgressBarValue2="calculateProgressBarValue2"
          @emitProgressBarValue3="calculateProgressBarValue3"
          @emitProgressBarValue4="calculateProgressBarValue4"
          @emitProgressBarValue5="calculateProgressBarValue5"
          @emitProgressBarValue6="calculateProgressBarValue6"
          @emitProgressBarValue7="calculateProgressBarValue7"
          @emitProgressBarValue8="calculateProgressBarValue8"
        />
      </d-col>
    </d-row>
    <d-row>
      <d-col lg="4"> </d-col>
      <d-col lg="8">
        <d-card class="card-small mb-4">
          <!-- Card Header -->
          <d-card-header class="border-bottom">
            <h6 class="m-0">{{ title }}</h6>
          </d-card-header>

          <d-list-group flush>
            <d-list-group-item class="p-3">
              <d-row>
                <d-col>
                  <d-form onsubmit="return false">
                    <d-form-row>
                      <!-- First Name -->
                      <d-col md="4" class="form-group">
                        <label>Intrested</label>
                        <d-select id="feInrested" v-model="personIntrest">
                          <option selected>Dance</option>
                          <option>Music</option>
                          <option>Painting</option>
                          <option>Singing</option>
                        </d-select>
                      </d-col>

                      <!-- Last Name -->
                      <d-col md="6" class="form-group">
                        <label>Select Competition category</label>
                        <d-select id="fecategory" v-model="competitionCategory">
                          <option>
                            Young Solo Performers (under the age of 21)
                          </option>
                          <option>Solo Performers (over the age of 21)</option>
                          <option>Composers</option>
                          <option>Ensemble</option>
                        </d-select>
                      </d-col>
                    </d-form-row>

                    <d-form-row>
                      <!-- Email -->
                      <d-col md="12" class="form-group">
                        <label>Instrumentation</label>
                        <d-form-input
                          type="text"
                          id="fetext"
                          placeholder="Instrumentation"
                          v-model="instrumentInput"
                        />
                      </d-col>
                    </d-form-row>

                    <div class="form-group">
                      <label for="felink"
                        >You can also provide links to free online streaming
                        platforms (YouTube, Vemeo, Dailymotion, Soundcloud).
                        Make sure the links are valid at least for a
                        year.</label
                      >
                      <d-form-input
                        type="text"
                        id="felink"
                        placeholder="URL"
                        v-model="urlStreaming"
                      />
                    </div>

                    <d-form-row>
                      <d-col md="12" class="form-group">
                        <label for="feComments">Other Comments</label>
                        <d-form-input
                          type="text"
                          id="feComments"
                          v-model="commentsInput"
                        />
                      </d-col>
                    </d-form-row>
                    <!-- Lab3: Write your code here  -->
                    <d-button
                      type="submit"
                      class="btn-accent"
                      @click="submitData"
                      >Save</d-button
                    >
                    <d-modal v-if="submitModal" @close="closePopup">
                      <d-modal-header>
                        <d-modal-title>Successfully Submitted</d-modal-title>
                      </d-modal-header>
                      <d-modal-body
                        >You have Successfully submitted the form</d-modal-body
                      >
                      <d-button @click="closePopup">Close</d-button>
                    </d-modal>
                  </d-form>
                </d-col>
              </d-row>
            </d-list-group-item>
          </d-list-group>
        </d-card>
      </d-col>
    </d-row>
  </d-container>
</template>

<script>
import UserDetails from '@/components/user-profile-lite/UserDetails.vue';
import UserAccountDetails from '@/components/user-profile-lite/UserAccountDetails.vue';
import mixins from '@/mixins/mixins.js';

export default {
  name: 'user-profile-lite',
  data() {
    return {
      personIntrest: '',
      competitionCategory: '',
      instrumentInput: '',
      urlStreaming: '',
      commentsInput: '',
      defaultUserDetails: {
        name: 'Sierra Brooks',
        avatar: require('@/assets/images/avatars/0.jpg'),
        jobTitle: 'Dancer',
        performanceReportTitle: 'Liked by',
        performanceReportValue: 0,
        metaTitle: 'Description',
        metaValue:
          'I enjoy how varied dance can be and the freedom of expression it gives. I love ballet in particular because of its beauty and complexity. Dancing makes me feel calm after a busy day, as well as energised. It clears my mind and gives me a natural energy boost. I love the fact that whatever has happened during my day or week I can leave it behind as soon as I put my ballet shoes on.',
      },
      submitModal: false,
    };
  },
  props: {
    /**
     * The component title.
     */
    title: {
      type: String,
      default: 'More Details',
    },
  },
  components: {
    uplUserDetails: UserDetails,
    uplUserAccountDetails: UserAccountDetails,
  },
  mixins: [
    mixins,
  ],
  created() {
    this.visitedCount('profile');
  },
  methods: {
    submitData() {
      console.log(this.$refs.userAccountDetails);
      const data = this.$refs.userAccountDetails.getUserDetails();
      data.personIntrest = this.personIntrest;
      data.competitionCategory = this.competitionCategory;
      data.instrumentInput = this.instrumentInput;
      data.urlStreaming = this.urlStreaming;
      data.commentsInput = this.commentsInput;
      localStorage.setItem('userDetails', JSON.stringify(data));
      this.submitModal = true;
    },
    calculateProgressBarValue(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue1(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue2(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue3(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue4(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue5(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue6(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue7(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    calculateProgressBarValue8(event) {
      this.defaultUserDetails.performanceReportValue = event;
    },
    closePopup() {
      this.submitModal = false;
    },
  },
};
</script>

