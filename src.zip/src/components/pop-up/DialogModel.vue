<template>
  <div>
    <d-modal v-if="showModal" @close="handleClose">
      <d-modal-header>
        <d-modal-title>Are you Sure?</d-modal-title>
      </d-modal-header>
      <d-modal-body>Are you sure you want to register</d-modal-body>
      <d-btn @click="confirmPopup">Yes</d-btn>
      <dialogpopup/>
      <d-btn @click="handleClose">Cancel</d-btn>
    </d-modal>
  </div>
</template>

<script>
import dialogpopup from "../pop-up/DialogPopup.vue"
export default {
  name: 'DialogModel',
  data() {
    return {
      showModal: false,
    };
  },
  components:{
    dialogpopup,
  },
  methods: {
    confirmPopup() {
      this.popUpModal = true;
    },
    handleClick() {
      this.showModal = true;
    },
    handleClose() {
      this.showModal = false;
    },
  },
};
</script>
