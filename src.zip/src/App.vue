<template>
  <component :is="layout">
    <router-view/>
  </component>
</template>

<script>
export default {
  computed: {
    layout() {
      return `${this.$route.meta.layout || 'default'}-layout`;
    },
  },
  created() {
    localStorage.setItem('home', '0');
    localStorage.setItem('talentZone', '0');
    localStorage.setItem('profile', '0');
  },
};
</script>
