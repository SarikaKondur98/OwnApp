export default {
  methods: {
    visitedCount(pageName) {
      const visitedNumber = localStorage.getItem(pageName);
      localStorage.setItem(pageName, Number(visitedNumber) + 1);
    },
  },
};
