<template>
  <d-container fluid class="main-content-container px-4"><br/><br/>
    <!-- Page Header -->
    <!-- <div>Opened: <span :class="[opened ? 'text-success' : 'text-danger']">{{ opened }}</span></div> -->
        
    <d-row no-gutters class="page-header py-4">
      <d-col col sm="4" class="text-center text-sm-left mb-4 mb-sm-0">
        <h3 class="page-title">Competition</h3>
      </d-col>
    </d-row>
    <d-row>
      <!-- Users Overview -->
      <d-col lg="8" md="6" sm="12" class="mb-4">
        <d-row>
           <d-col lg v-for="(stats, idx) in smallStats" :key="idx" class="mb-4">
             <small-stats :id="`small-stats-${idx}`" :label="stats.label" :value="stats.value"/>
          </d-col>
        </d-row>
      </d-col>

      <!-- Users by Device (lite) -->
      <d-col lg="4" md="6" sm="12" class="mb-4">
        <boProfileProgress />
      </d-col>
    </d-row>

    <d-row>
      <!-- Users Overview -->
      <d-col  lg="8" md="12" sm="12" class="mb-4">
        <bo-discussions @approve="handleApprove" @reject="handleReject" @edit="handleEdit" @view-all-comments="handleViewAllComments" />
      </d-col>
      <!-- Users by Device (lite) -->
      <d-col lg="4" md="6" sm="12" class="mb-4">
        <bo-top-referrals />
      </d-col>
    </d-row>
  </d-container>
</template>

<script>
import SmallStats from '@/components/common/SmallStats.vue';
import TopReferrals from '@/components/common/TopReferrals.vue';
import UsersOverview from '@/components/blog/UsersOverview.vue';
import UsersByDevice from '@/components/blog/UsersByDeviceLite.vue';
import NewDraft from '@/components/blog/NewDraft.vue';
import Discussions from '@/components/blog/Discussions.vue';
import ProfileProgress from  '@/components/blog/ProfileProgress';
import mixins from '@/mixins/mixins.js';

export default {
  components: {
    SmallStats,
    boUsersOverview: UsersOverview,
    boUsersByDevice: UsersByDevice,
    boNewDraft: NewDraft,
    boDiscussions: Discussions,
    boTopReferrals: TopReferrals,
    boProfileProgress: ProfileProgress,
  },
  data() {
    return {
      dateRange: {
        from: null,
        to: null,
      },
    };
  },
  mixins: [
    mixins,
  ],
  created() {
    this.visitedCount('home');
  },
  methods: {
    handleApprove(id) {
      alert(`Approving discussion id: ${id}`); // eslint-disable-line no-alert
    },
    handleReject(id) {
      alert(`Rejecting discussion id: ${id}`); // eslint-disable-line no-alert
    },
    handleEdit(id) {
      alert(`Editing discussion id: ${id}`); // eslint-disable-line no-alert
    },
    handleViewAllComments() {
      alert('Viewing all comments!'); // eslint-disable-line no-alert
    },
  },
  computed: {
    smallStats() {
      return [{
        label: 'Registered',
        value: '2,390',
      }, {
        label: 'Participated',
        value: '182',
      },{
        label: 'Won',
        value: '17,281',
      }];
    },
  },
};
</script>

