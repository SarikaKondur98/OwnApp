<template>
  <d-card class="card-small mb-4 pt-3">
    <!-- Card Header -->
    <d-card-header class="border-bottom text-center">
      <!-- User Avatar -->
      <div class="mb-3 mx-auto">
        <img
          class="rounded-circle"
          id="myImg"
          :src="userDetails.avatar"
          :alt="userDetails.name"
          width="110"
        />
      </div>
      <input type="file" class="picture" @change="EditPic($event)" />
      <!-- User Name -->
      <h4 class="mb-0">{{ userDetails.name }}</h4>

      <!-- User Job Title -->
      <span class="text-muted d-block mb-2">{{ userDetails.jobTitle }}</span>

      <!-- User Follow -->
      <d-button pill outline size="sm" class="mb-2">
        <i class="material-icons mr-1">person_add</i> Follow</d-button
      ><br />
      <d-button
        pill
        outline
        size="sm"
        class="mb-2 mr-2"
        @click="socialMediaLink1()"
        ><a>LinkedIn</a></d-button
      >
      <d-button
        pill
        outline
        size="sm"
        class="mb-2 mr-2"
        @click="socialMediaLink2()"
        ><a>Facebook</a></d-button
      >
      <d-button
        pill
        outline
        size="sm"
        class="mb-2 mr-2"
        @click="socialMediaLink3()"
        ><a>Twitter</a></d-button
      >
      <!-- Lab1: Write your code here -->
    </d-card-header>

    <d-list-group flush>
      <!-- User Performance Report -->
      <d-list-group-item class="px-4">
        <div class="progress-wrapper">
          <strong class="text-muted d-block mb-2">{{
            userDetails.performanceReportTitle
          }}</strong>
          <d-progress class="progress-sm">
            <span class="progress-value"
              >{{ userDetails.performanceReportValue }}%</span
            >
            <d-progress-bar
              :max="100"
              :value="userDetails.performanceReportValue"
            />
          </d-progress>
        </div>
      </d-list-group-item>

      <!-- User Meta -->
      <d-list-group-item>
        <strong class="text-muted d-block mb-2">{{
          userDetails.metaTitle
        }}</strong>
        <span class="text-center">{{ userDetails.metaValue }}</span>
      </d-list-group-item>
    </d-list-group>
  </d-card>
</template>

<script>
const defaultUserDetails = {
  name: 'Sierra Brooks',
  avatar: require('@/assets/images/avatars/0.jpg'),
  jobTitle: 'Dancer',
  performanceReportTitle: 'Liked by',
  performanceReportValue: 74,
  metaTitle: 'Description',
  metaValue:
    'I enjoy how varied dance can be and the freedom of expression it gives. I love ballet in particular because of its beauty and complexity. Dancing makes me feel calm after a busy day, as well as energised. It clears my mind and gives me a natural energy boost. I love the fact that whatever has happened during my day or week I can leave it behind as soon as I put my ballet shoes on.',
};

export default {
  name: 'user-details',
  props: {
    /**
     * The user details.
     */
    userDetails: {
      type: Object,
      default() {
        return defaultUserDetails;
      },
    },
  },
  methods: {
    socialMediaLink1() {
      window.open('https://www.linkedin.com/login');
    },
    socialMediaLink2() {
      window.open('https://www.facebook.com/');
    },
    socialMediaLink3() {
      window.open('https://twitter.com/?lang=en');
    },
    EditPic(event) {
      this.userDetails.avatar = URL.createObjectURL(event.target.files[0]);
    },
  },
};
</script>

<style>
#myImg:hover {
  filter: blur(4px);
  transition: 0.5s ease-in-out;
  cursor: pointer;
}
.picture {
  height: 100px;
  width: 150px;
  opacity: 0;
  position: absolute;
  left: 100px;
  top: 20px;
}
</style>
