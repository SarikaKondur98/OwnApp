<template>
  <d-card class="card-small mb-4">
    <!-- Card Header -->
    <d-card-header class="border-bottom">
      <h6 class="m-0">{{ title }}</h6>
      <d-button pill outline size="sm" class="mr-2" @click="EditInput()"
        >Edit</d-button
      >
    </d-card-header>

    <d-list-group flush>
      <d-list-group-item class="p-3">
        <d-row>
          <d-col>
            <d-form>
              <d-form-row>
                <!-- Lab 4 : Write your code here -->

                <!-- First Name -->
                <d-col md="6" class="form-group">
                  <label for="feFirstName">First Name</label>
                  <label
                    class="firstnameError"
                    v-if="userDetailsObj.firstName == ''"
                    >*Enter Your First Name</label
                  >
                  <d-form-input
                    type="text"
                    id="feFirstName"
                    placeholder="First Name"
                    v-model="userDetailsObj.firstName"
                    disabled="true"
                    @input="enterFirstName"
                  />
                </d-col>

                <!-- Last Name -->
                <d-col md="6" class="form-group">
                  <label for="feLastName">Last Name</label>
                  <label
                    class="firstnameError"
                    v-if="userDetailsObj.lastName == ''"
                    >*Enter Your Last Name</label
                  >
                  <d-form-input
                    type="text"
                    id="feLastName"
                    placeholder="Last Name"
                    v-model="userDetailsObj.lastName"
                    disabled="true"
                    @input="enterLastName"
                  />
                </d-col>
              </d-form-row>

              <d-form-row>
                <!-- Email -->
                <d-col md="6" class="form-group">
                  <label for="feEmail">Email</label>
                  <label
                    id="emailError"
                    class="firstnameError"
                    ></label
                  >
                  <d-form-input
                    type="email"
                    id="feEmail"
                    placeholder="Email Address"
                    v-model="userDetailsObj.emailAddress"
                    disabled="true"
                    @input="enterEmail"
                    @change="checkEmail"
                  />
                </d-col>

                <!-- Password -->
                <d-col md="6" class="form-group">
                  <label for="fePassword">Password</label>
                  <label
                    class="firstnameError"
                    v-if="userDetailsObj.passwordInput == ''"
                    >*Enter Your Password</label
                  >
                  <d-form-input
                    type="password"
                    id="fePassword"
                    placeholder="Last Name"
                    v-model="userDetailsObj.passwordInput"
                    disabled="true"
                    @input="enterPass"
                  />
                </d-col>
              </d-form-row>

              <!-- Address -->
              <div class="form-group">
                <label for="feInputAddress">Address</label>
                <label
                  class="firstnameError"
                  v-if="userDetailsObj.addressFirst == ''"
                  >*Enter Your Address</label
                >
                <d-form-input
                  type="text"
                  id="feInputAddress"
                  placeholder="Enter Your Address"
                  v-model="userDetailsObj.addressFirst"
                  disabled="true"
                  @input="enterAddress"
                />
              </div>
              <d-form-row>
                <d-col md="6" class="form-group">
                  <label for="feInputCountry">Country</label>
                  <d-select
                    id="feCountry"
                    v-model="userDetailsObj.countryInput"
                    @change="getStateByCountries()"
                    @input="enterCountry"
                  >
                    <option v-for="(country, i) in countriesList" :key="i">
                      {{ country }}
                    </option>
                  </d-select>
                </d-col>
              </d-form-row>
              <d-form-row>
                <!-- State -->
                <d-col md="4" class="form-group">
                  <label for="feInputState">State</label>
                  <d-select
                    id="feInputState"
                    v-model="userDetailsObj.stateInput"
                    @change="getCityByStates()"
                    @input="enterState"
                  >
                    <option v-for="(state, i) in statesList" :key="i">
                      {{ state }}
                    </option>
                  </d-select>
                </d-col>
                <!-- City -->
                <d-col md="4" class="form-group">
                  <label for="feInputCity">City</label>
                  <d-select
                    id="feInputState"
                    v-model="userDetailsObj.cityInput"
                    @input="enterCity"
                  >
                    <option v-for="(city, i) in cities" :key="i">
                      {{ city }}
                    </option>
                  </d-select>
                </d-col>

                <!-- Zip Code -->
              </d-form-row>

              <d-form-row>
                <!-- Description -->
                <d-col md="12" class="form-group">
                  <label for="feDescription">Description</label>
                  <label class="firstnameError" v-if="descriptionText == ''"
                    >*Enter Description</label
                  >
                  <d-textarea
                    name="feDescription"
                    rows="5"
                    id="feDescriptionInput"
                    v-model="userDetailsObj.descriptionText"
                    @input="enterDescription"
                  ></d-textarea>
                </d-col>
              </d-form-row>
              <!-- <d-button
                pill
                outline
                size="sm"
                class="mb-2 mr-2"
                @click="saveDetails()"
                >Save Account Details</d-button
              > -->
            </d-form>
          </d-col>
        </d-row>
      </d-list-group-item>
    </d-list-group>
  </d-card>
</template>

<script>
const yourhandle = require('countrycitystatejson');

export default {
  name: 'user-account-details',
  data() {
    return {
      userDetailsObj: {
        firstName: '',
        lastName: '',
        emailAddress: '',
        passwordInput: '',
        addressFirst: '',
        descriptionText: '',
        countryInput: '',
        cityInput: '',
        stateInput: '',
      },
      countries: yourhandle.getCountriesShort(),
      states: {},
      countriesList: [],
      statesList: [],
      cities: [],
      progressValue: 11,
    };
  },
  props: {
    /**
     * The component title.
     */
    title: {
      type: String,
      default: 'Account Details',
    },
  },
  mounted() {
    this.countriesList = this.countries;
    console.log(this.countriesList);
  },
  methods: {
    enterFirstName() {
      if (
        this.userDetailsObj.firstName !== '' &&
        this.userDetailsObj.firstName !== null
      ) {
        const progressValue1 = this.progressValue;
        this.$emit('emitProgressBarValue', progressValue1);
      }
    },
    enterLastName() {
      if (
        this.userDetailsObj.lastName !== '' &&
        this.userDetailsObj.lastName !== null
      ) {
        const progressValue2 = 2 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue2);
      }
    },
    enterEmail() {
      if (
        this.userDetailsObj.emailAddress !== '' &&
        this.userDetailsObj.emailAddress !== null
      ) {
        const progressValue3 = 3 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue3);
      }
    },
    enterPass() {
      if (
        this.userDetailsObj.passwordInput !== '' &&
        this.userDetailsObj.passwordInput !== null
      ) {
        const progressValue4 = 4 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue4);
      }
    },
    enterAddress() {
      if (
        this.userDetailsObj.addressFirst !== '' &&
        this.userDetailsObj.addressFirst !== null
      ) {
        const progressValue5 = 5 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue5);
      }
    },
    enterCountry() {
      if (
        this.userDetailsObj.countryInput !== '' &&
        this.userDetailsObj.countryInput !== null
      ) {
        const progressValue6 = 6 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue6);
      }
    },
    enterState() {
      if (
        this.userDetailsObj.stateInput !== '' &&
        this.userDetailsObj.stateInput !== null
      ) {
        const progressValue7 = 7 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue7);
      }
    },
    enterCity() {
      if (
        this.userDetailsObj.cityInput !== '' &&
        this.userDetailsObj.cityInput !== null
      ) {
        const progressValue8 = 8 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue8);
      }
    },
    enterDescription() {
      if (
        this.userDetailsObj.descriptionText !== '' &&
        this.userDetailsObj.descriptionText !== null
      ) {
        const progressValue9 = 9 * this.progressValue;
        this.$emit('emitProgressBarValue', progressValue9);
      }
    },
    getCityByStates() {
      const countryName = this.userDetailsObj.countryInput;
      const stateName = document.getElementById('feInputState').value;
      this.cities = yourhandle.getCities(countryName, stateName);
      console.log(this.cities);
    },
    getStateByCountries() {
      const countryName = this.userDetailsObj.countryInput;
      this.states = yourhandle.getCountryByShort(countryName);
      this.statesList = Object.keys(this.states.states);
      console.log(this.statesList);
    },
    getUserDetails() {
      const userData = { ...this.userDetailsObj };
      // localStorage.setItem('userDetailedData', userData);
      // this.$emit('saveAccountdetails', userData);
      return userData;
    },
    EditInput() {
      document.getElementById('feFirstName').disabled = false;
      document.getElementById('feLastName').disabled = false;
      document.getElementById('feEmail').disabled = false;
      document.getElementById('fePassword').disabled = false;
      document.getElementById('feInputAddress').disabled = false;
      document.getElementById('feInputCity').disabled = false;
      document.getElementById('feInputState').disabled = false;
      document.getElementById('feDescriptionInput').disabled = false;
    },
    checkEmail() {
      const email = document.getElementById('feEmail');
      const filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

      if (!filter.test(email.value)) {
        document.getElementById('emailError').textContent = '*Please Enter a Valid Email Address';
        document.getElementById('emailError').style.color = 'red';
        return false;
      }
      document.getElementById('emailError').style.display = 'none';
      return true;
    },
  },
};
</script>

<style>
.firstnameError {
  color: red;
  font-size: 12px;
  padding: 12px;
}
</style>
