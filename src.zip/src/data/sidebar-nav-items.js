export default function () {
  return [{
    title: 'Home',
    to: {
      name: 'blog-overview',
    },
    htmlBefore: '<i class="material-icons">home</i>',
    htmlAfter: '',
  }, {
    title: 'Talent Zone',
    htmlBefore: '<i class="material-icons">vertical_split</i>',
    to: {
      name: 'blog-posts',
    },
  }, {
    title: 'Profile',
    htmlBefore: '<i class="material-icons">person</i>',
    to: {
      name: 'user-profile-lite',
    },
  },
  ];
}
