<template>
  <d-container fluid class="main-content-container px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
      <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <h3 class="page-title">Talent Zone</h3>
        <div>
          📅 Date: <span id="filterDatePicker">{{ getFormattedDate() }}</span>
        </div>
        <d-datepicker
          id="datePickerFilter"
          v-model="date"
          @opened="handleOpened"
          @closed="handleClosed"
          typeable
          @input="getFilteredReports"
        />
        <!-- <input type="date" id="filterDatePicker"> -->
      </div>
    </div>

    <!-- Second Row of Posts -->
    <d-row>
      <d-col
        v-for="(post, idx) in postLists"
        :key="idx"
        lg="6"
        sm="12"
        class="mb-4"
      >
        <d-card class="card-small card-post card-post--aside card-post--1">
          <div
            class="card-post__image"
            :style="{
              backgroundImage: 'url(\'' + post.backgroundImage + '\')',
            }"
          >
            <d-badge
              pill
              :class="['card-post__category', 'bg-' + post.categoryTheme]"
              >{{ post.category }}</d-badge
            >
            <!-- <div class="card-post__author d-flex">
              <a href="#" class="card-post__author-avatar card-post__author-avatar--small" :style="{ backgroundImage: 'url(\'' + post.authorAvatar + '\')' }">Written by Anna Ken</a>
            </div> -->
          </div>
          <d-card-body>
            <h5 class="card-title">
              <a class="text-fiord-blue" href="#">{{ post.title }}</a>
            </h5>
            <p class="card-text d-inline-block mb-3">{{ post.body }}</p>
            <div class="my-auto ml-auto">
              <span class="text-muted"
                >{{ post.date }} | <i class="material-icons">edit</i>
                <span id="registerNum">{{ post.registered }}</span></span
              >
              <d-button
                size="sm"
                class="btn-white float-right"
                @click.native="registerPopup"
              >
                <i class="far fa-bookmark mr-1"></i> Register
              </d-button>
              <d-modal v-if="showModal" @close="handleClose">
                <d-modal-header>
                  <d-modal-title>Are You Sure ?</d-modal-title>
                </d-modal-header>
                <d-modal-body
                  >Are you sure you want to get registered ?</d-modal-body
                >
                <d-button
                  pill
                  outline
                  size="sm"
                  class="confirmBtn"
                  @click.native="confirmPopup"
                  >Yes</d-button
                >
                <d-button
                  pill
                  outline
                  size="sm"
                  class="cancelBtn"
                  @click.native="handleClose"
                  >Cancel</d-button
                ><br/>
              </d-modal>
              <d-modal v-if="popupModal" @close="closePopup">
                <d-modal-header>
                  <d-modal-title>Successfully Registered</d-modal-title>
                </d-modal-header>
                <d-modal-body
                  >You are Successfully Registered</d-modal-body
                >
              </d-modal>
            </div>
          </d-card-body>
        </d-card>
      </d-col>
    </d-row>
    <!-- <d-modal v-if="isClicked" id="modal-center" centered title="BootstrapVue">
      <p class="my-4">Vertically centered modal!</p>
    </d-modal> -->
  </d-container>
</template>

<script>
import moment from '../../node_modules/moment';
import dialogpopup from '../components/pop-up/DialogPopup.vue';
import mixins from '@/mixins/mixins.js';
// Second Row of posts
const PostsListTwo = [
  {
    backgroundImage: require('@/assets/images/content-management/18.jpg'),
    category: 'Music',
    categoryTheme: 'info',
    registered: '1230',
    author: 'Anna Ken',
    authorAvatar: require('@/assets/images/avatars/0.jpg'),
    title: '2021 Pianist Composing Competition now open',
    body: 'Now in its 5th year, the annual Composing Competition has been a huge hit with aspiring pianists and composers around the world. Last year..... ',
    date: '18 February 2021',
  },
  {
    backgroundImage: require('@/assets/images/content-management/17.jpg'),
    category: 'Dance',
    categoryTheme: 'dark',
    registered: '2563',
    author: 'John James',
    authorAvatar: require('@/assets/images/avatars/1.jpg'),
    title: 'National Dance Competition 2021',
    body: 'If you had a great time at one of our regional competitions, you ll LOVE our National events! Join us for a week of unforgettable fun .....',
    date: '06 February 2021',
  },
  {
    backgroundImage: require('@/assets/images/content-management/19.jpg'),
    category: 'Painting',
    categoryTheme: 'dark',
    registered: '8562',
    author: 'John James',
    authorAvatar: require('@/assets/images/avatars/1.jpg'),
    title: 'Online painting and drawing competition 2021',
    body: 'The free online Drawing competition by contest zeal helps to stimulate kids artists, school students, young artists, and senior people to .....',
    date: '19 February 2021',
  },
  {
    backgroundImage: require('@/assets/images/content-management/20.jpg'),
    category: 'Singing',
    categoryTheme: 'dark',
    registered: '8563',
    author: 'John James',
    authorAvatar: require('@/assets/images/avatars/1.jpg'),
    title: 'The Voice India 2021 Auditions And Registration',
    body: 'The Voice India is one of the best singing reality show in India for all singers. This is a very great opportunity for all upcoming singers.....',
    date: '29 February 2021',
  },
];

export default {
  data() {
    return {
      PostsListTwo,
      opened: false,
      date: new Date(),
      showModal: false,
      popupModal: false,
      postLists: [],
      sampleArr: [],
      registeredCount: '',
    };
  },
  components: {
    moment,
    dialogpopup,
  },
  mounted() {
    this.postLists = this.PostsListTwo.slice(0);
  },
  mixins: [
    mixins,
  ],
  created() {
    this.visitedCount('talentZone');
  },
  methods: {
    getFilteredReports() {
      debugger;
      const date = this.getFormattedDate();
      const selectedReport = this.PostsListTwo.filter((report) => {
        if (report.date.includes(date)) {
          return report;
        }
      });
      debugger;
      this.postLists =
        selectedReport.length > 0 ? selectedReport.slice(0) : this.PostsListTwo;
    },
    getFormattedDate() {
      const todayDate = this.date.getDate();
      const month = this.date.toLocaleString('default', { month: 'long' });
      const fullYear = this.date.getFullYear();
      const fullDate = `${todayDate} ${month} ${fullYear}`;
      return fullDate;
    },
    handleOpened() {
      this.opened = true;
    },
    handleClosed() {
      this.opened = false;
    },
    registerPopup() {
      this.showModal = true;
    },
    handleClose() {
      this.showModal = false;
    },
    confirmPopup() {
      this.popupModal = true;
    },
    closePopup() {
      this.popupModal = false;
      this.sampleArr = this.PostsListTwo;
      console.log(this.sampleArr);
      this.sampleArr.forEach((element) => {
        ++element.registered;
      });
    },
  },
};
</script>

<style>
.confirmBtn{
  margin-right: 295px;
  margin-left: 32px;
}
.cancelBtn{
  margin-left: 295px;
  margin-top: -30px;
  margin-right: 30px;
}
</style>

